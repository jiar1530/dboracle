package com.selenium.database;
import java.sql.Connection;
import java.sql.SQLException;

import com.selenium.config.BaseConfig;

public class MainConexionOracle extends BaseConfig {

	 public static String Capital = "";
	 public static  String Departamento ="";
	 public static int Select= 0;
	 // public static void main(String[] args) {
	  public void data () {
		// TODO Auto-generated method stub
		DBOracle oracle=new DBOracle();
		Connection con;
		
		con=oracle.conectar();

		
		//System.out.println("\n\tConsulta metadata");
		//oracle.consultaMetadata();		

		//System.out.println("\n\tConsulta Preparada");
    	//oracle.consPreparada();
		//System.out.println("Actualizacion preparada");
		
		//int i = 36;

        for(int i=0; i<=36 ; i++) {
			Select =i;
		oracle.consPreparada(Select);
		if (DBOracle.Capital == DBOracle.Departamento )
		{
			DBOracle.Capital = "Pasto";
			DBOracle.Departamento = "NAriño";		
		}
		
		 Capital= DBOracle.Capital;
		 Departamento =DBOracle.Departamento;
		 
			
		System.out.println(Capital);
		System.out.println(Departamento);
        }
		
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	

}
