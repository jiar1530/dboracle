package com.selenium.database;
import java.sql.Statement;
import java.sql.Types;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class DBOracle {
	public static String Departamento;
    public static String Capital;

    
  // public DBOracle (String Departamento, String Capital) { 
	//   this.Capital = Capital;
	//   this.Departamento = Departamento;
  // }
private Connection conexion;

public Connection getConexion(){
	return conexion;
}
public void setConexion(Connection conexion){
	this.conexion=conexion;
}
	public Connection conectar(){
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			String baseDeDatos="jdbc:oracle:thin:@LOCALHOST:1521:XE";
			
			conexion =DriverManager.getConnection(baseDeDatos,"system","Pa$$w0rd");
			
			
			if(conexion!=null){
				System.out.println("Conexion establecida");
			}else{
				System.out.println("Error al conectar");
			}

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conexion;
	}
	
	
	
   	public void consultaMetadata(){
 		
		String cons="Select * from DEPT";
		try {
			Statement sentencia=conexion.createStatement();
			ResultSet resultado;
			resultado = sentencia.executeQuery(cons);
			ResultSetMetaData resultSetMetaData=resultado.getMetaData();
			int nColumnas= resultSetMetaData.getColumnCount();
			for (int i = 1; i <= nColumnas; i++) {
				//obtiene el nombre de las columnas
				System.out.println("NOMBRE: "+resultSetMetaData.getColumnName(i));
				//obtiene el maximo de tama�o de cada columna
				System.out.println("Tama�o:"+ resultSetMetaData.getColumnDisplaySize(i));
				if (resultSetMetaData.isNullable(i)==0) {
					System.out.println("La columna puede ser nula: " +resultSetMetaData.getColumnName(i));
				}
			}
			
			resultado.close();
			sentencia.close();
			//conexion.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
	}
	
	public void consPreparada(int numero ){
		    String sql ="select * from dept where deptno= ?";
		    String concatena="";
		 
		 // String sql ="select * from dept";
		try {
			PreparedStatement sentencia=conexion.prepareStatement(sql);
			sentencia.setInt(1, numero);
			ResultSet res;
			res=sentencia.executeQuery();
			while (res.next()) {
				
				//System.out.println(res.getString(1));
				//System.out.println(res.getString(2));
				//System.out.println(res.getString(3));
				//concatena = res.getString(2) + ","+ res.getString(3);
				Departamento = res.getString(2);
				Capital = res.getString(3);
				
			}
			sentencia.close();
			res.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
		System.out.println(concatena);
	}
	
	    public void TotalData(){
	
	    String sql ="select * from dept";
	     
	try {
		PreparedStatement sentencia=conexion.prepareStatement(sql);
		
		ResultSet res;
		res=sentencia.executeQuery();
			
		ResultSetMetaData infoResultados = res.getMetaData();
		//int col = infoResultados.getColumnCount();
		  
		int col = 1;
		while (res.next()) {
		   for (int i = 1; i <=col; i++ ) {
		 	//System.out.println(res.getString(i) + "\t");
			  // System.out.println(res.getString(1));
			 //  System.out.println(res.getString(2));
			   Departamento = res.getString(2);
			   System.out.println("El Departamento es: " + Departamento);
			   
			   //System.out.println(res.getString(3));
			   Capital = res.getString(3);
			   System.out.println ("La Capital es: " +Capital);
			  
			   
		   }
		}
		sentencia.close();
		res.close();
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	

}
	
	
}

	

