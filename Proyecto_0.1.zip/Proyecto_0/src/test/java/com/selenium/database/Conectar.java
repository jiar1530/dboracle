package com.selenium.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Conectar {
	
	private Connection conexion;

	public Connection getConexion(){
		return conexion;
	}
	public void setConexion(Connection conexion){
		this.conexion=conexion;
	}	
	public Connection conectar(){
		try {
			  
			  Class.forName("oracle.jdbc.OracleDriver");
			  //String databaseURL = "jdbc:oracle:thin:@LOCALHOST:1521:XE";
			  String databaseURL = "jdbc:oracle:thin:@//10.109.233.211:1529/CIFP";
			  
			 conexion = DriverManager.getConnection(databaseURL,"OPS$JPATACO","Pa$$w0rd");
			  
				if(conexion!=null){
					System.out.println("Conexion establecida");
				}else{
					System.out.println("Error al conectar");
				}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 return conexion;
	
 }
}