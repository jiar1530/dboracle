package com.selenium.page;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.selenium.config.BaseConfig;
import com.selenium.database.DBOracle;
import com.selenium.database.MainConexionOracle;

public class HomePage extends BaseConfig {

	/**
	 * @param nombre
	 */

		
  public HomePage(WebDriver driver) {
    super();
    this.driver = driver;
    PageFactory.initElements(driver, this);
  }

  //create Element 
  

  String resultado; 

  @FindBy(id = "ciudad")
  private WebElement BuscarCiudad; 
  

  @FindBy(xpath = "//*[@id=\"fw_c\"]/div[3]/div[1]/div/div/div/div[2]/div/div/div/div/div/select")
  private WebElement BuscarRegional; 
  

  @FindBy(xpath = "//*[@id=\"fw_c\"]/div[3]/div[1]/div/div/div/div[3]/div/div/div[1]/div/div/input")
  private WebElement PalabraClave;
  

  @FindBy(xpath = "//*[@id=\"b_wvt3iamfjmupynk52bmk\"]/button")
  private WebElement BotonBuscar;
  
  
  //create method
  
    public HomePage proyectosEnOferta() {
    	
    	MainConexionOracle oMain = new MainConexionOracle();
	    //BuscarCiudad.sendKeys("Bogota");
    	
    	for (int i = 1; i <=36; i++ ) {
    		oMain.Select = i;
    	
    	BuscarCiudad.sendKeys();
	    BuscarRegional.sendKeys(oMain.Departamento);
	    System.out.println(oMain.Capital);
	    System.out.println(oMain.Departamento);
	    BotonBuscar.click();
	    driver.close();
	    
	  
    	}
    	 System.out.println("SUERTE3");
    	  return new HomePage(driver);
    	 
	  
	  }
    
    public void validCartItem() {
    	MainConexionOracle oMain = new MainConexionOracle();
    	for (int i = 1; i <=36; i++ ) {
    		oMain.Select = i;
    	
    	BuscarCiudad.sendKeys(oMain.Capital);
    	BuscarRegional.sendKeys(oMain.Departamento);
	    BotonBuscar.click();

	    //driver.quit();
    	
      }
    }
}
