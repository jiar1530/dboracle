package com.selenium.entities;

public class Casa {
    
    private String nombre_casa;
    
    public Casa(String nombre_casa) {
   
	super();

      this.nombre_casa = nombre_casa;
    }
  
}
