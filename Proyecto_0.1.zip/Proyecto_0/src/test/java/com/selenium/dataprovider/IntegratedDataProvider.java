package com.selenium.dataprovider;

import org.testng.annotations.DataProvider;
import com.selenium.dataprovider.FileDataProvider;
import com.google.gson.Gson;
import com.selenium.entities.Casa;

public class IntegratedDataProvider {
  
  @DataProvider
  public static Object[][] buscarCasa() {
    Gson gson = new Gson();
    Casa product =
        gson.fromJson(
            FileDataProvider.asString(
                String.format("./resource/buscar.json")),
            Casa.class);
    return new Object[][] {{product}};
  }
  
}
