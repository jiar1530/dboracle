package com.selenium.test;


import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test4 {
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  
  
  
  @Before
  public void setUp() {
	  
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
	
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void test4() {
    driver.get("https://www.google.com/");
    driver.manage().window().setSize(new Dimension(1062, 668));
    driver.findElement(By.name("q")).sendKeys("Prueba jairo");
    driver.findElement(By.id("viewport")).click();
    driver.findElement(By.cssSelector("center:nth-child(1) > .gNO89b")).click();
  }
}