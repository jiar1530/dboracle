package com.selenium.test;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;


@RunWith(Parameterized.class)
public class Test02 {
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  
  @Parameterized.Parameters     
  
  public static Collection<Object[]> listaTextos() {
		  
		  List<Object[]> args = new ArrayList<>();
  
	

		  try {
		  
			  String databaseURL = "jdbc:oracle:thin:@LOCALHOST:1521:XE";
			  
			  Connection connection = DriverManager.getConnection(databaseURL,"system","Pa$$w0rd");
			  
				if(connection!=null){
					System.out.println("Conexion establecida");
				}else{
					System.out.println("Error al conectar");
				}
			  
			  
			  
			  String sql = "select DEPTNO,DNAME,CAP from dept";
					  
			  Statement statement = connection.createStatement();
			  
			  ResultSet result = statement.executeQuery(sql);
			  
			
			  
			  while (result.next()) {
				  
				  Object[] argumento = new Object[] { 
						  
			     result.getString(1),
				 result.getString(2),
				 result.getString(3),
			
				  };
				  
				  args.add(argumento);
				  
			  }
		  }
		  catch (Exception ex) {
			  // Do nothing ... 
		  }
			  
	return args;
	  }
		  
  private final String codigo;
  private final String Departamento;
  private final String Capital;  
		
  	 
  	 
 public  Test02(String codigo, String Departamento, String Capital){
 	     this.codigo = codigo;
	     this.Departamento = Departamento;
	     this.Capital = Capital;
 	
 	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Prueba\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
 	  driver = new ChromeDriver();
		  js = (JavascriptExecutor) driver;
		  vars = new HashMap<String, Object>();
		
 }
  
  @Before
  public void setUp() {
    
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\Prueba\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");  
	driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void test02() {
    driver.get("http://micasaya.minvivienda.gov.co/");
    driver.manage().window().setSize(new Dimension(1054, 662));
    driver.findElement(By.id("ciudad")).click();
    //driver.findElement(By.id("ciudad")).sendKeys("Cali");
    driver.findElement(By.id("ciudad")).sendKeys("Capital");
    driver.findElement(By.name("regional")).click();
    {
      WebElement dropdown = driver.findElement(By.name("Departamento"));
      dropdown.findElement(By.xpath("//option[. = 'Valle del Cauca']")).click();
    }
    driver.findElement(By.name("Departamento")).click();
    driver.findElement(By.cssSelector("div:nth-child(2) > #b_wvt3iamfjmupynk52bmk span")).click();
  }
}
