package com.selenium.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import com.selenium.database.Conectar;
import com.selenium.database.DBOracle;




//@RunWith(Parameterized.class)
public class Test5b{

	public static int id_hogar;
	private WebDriver driver;
	private Map<String, Object> vars;
	JavascriptExecutor js;
         
    
 // @Parameterized.Parameters     
    


			
    @Before
  public void setUp() {
    System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
     driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
 
    
          
    @After
    public void tearDown() {
      driver.quit();
    }   
    
	@Test
	public void deletemetest() {
	
		try {
		Conectar oracle=new Conectar();
		Connection con;
		
		con=oracle.conectar();
		
		  String sql = "Select ho.id_hogar from mcy_hogar ho where ho.id_hogar=3577";
		  
		
		  Statement statement = con.createStatement();
		  
		  
		  ResultSet result = statement.executeQuery(sql);
		  result.next();
		//  int id_hogar = result.getInt("ID_HOGAR");
		 
		  id_hogar = result.getInt("ID_HOGAR");
		  result.close();
		  statement.close();
		  System.out.println("id_hogar: "+ id_hogar);
		  
		}
		
		catch (Exception ex) {
			  // Do nothing ... 
		  }
		  
       driver.get("https://www.google.com/");
       driver.manage().window().setSize(new Dimension(1352, 674));
       driver.findElement(By.name("q")).click();
       driver.findElement(By.name("q")).sendKeys(Integer.toString(id_hogar)); 
       driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
       {
         WebElement element = driver.findElement(By.cssSelector(".g:nth-child(1) .LC20lb > span"));
         Actions builder = new Actions(driver);
         builder.moveToElement(element).perform();
       }
     
     
     }

	}
	

	
	
	
	

