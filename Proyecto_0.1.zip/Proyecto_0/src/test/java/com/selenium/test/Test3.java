package com.selenium.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.selenium.database.MainConexionOracle;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;


import org.junit.*;
import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import org.junit.runners.parameterized.*;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import org.junit.Test;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
 
import java.util.Arrays;
import java.util.Collection;




//@RunWith(Parameterized.class)
public class Test3{

	public static String Departamento;	
	//public static String codigo;
	//public static String nombre;
	//public static String descripcion;
	

	private WebDriver driver;
	private Map<String, Object> vars;
	JavascriptExecutor js;

     public String textoBusqueda;
     
    
   //@Parameterized.Parameters     
     	 public static Collection<Object[]> listaTextos() {
		  
		  List<Object[]> args = new ArrayList<>();
     
		//  args.add(new Object[] {"Hola Mundo"});

		  try {
		  
			  String databaseURL = "jdbc:oracle:thin:@LOCALHOST:1521:XE";
			  
			  Connection connection = DriverManager.getConnection(databaseURL,"system","Pa$$w0rd");
			  
				if(connection!=null){
					System.out.println("Conexion establecida");
				}else{
					System.out.println("Error al conectar");
				}
			  
			  
			  
			  String sql = "select DEPTNO,DNAME,CAP from dept";
					  
			  Statement statement = connection.createStatement();
			  
			  ResultSet result = statement.executeQuery(sql);
			  
			
			  
			  while (result.next()) {
				  
				//  Object[] argumento = new Object[] { 
						  
			     System.out.println(result.getString(1));
				 System.out.println(result.getString(2));
				 System.out.println(result.getString(3));
				//concatena = res.getString(2) + ","+ res.getString(3);
				 //Departamento = "Bogota";
				  	Departamento = result.getString(2);
				  };
				  
				//  args.add(argumento);
				  
			 // }
		  }
		  catch (Exception ex) {
			  // Do nothing ... 
		  }
			  
	return args;
	  }
		  
		  
		
     	 
     	 
    public  Test3(){
    	this.textoBusqueda = textoBusqueda;
    	//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Prueba\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
    	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
    	  driver = new ChromeDriver();
 		  js = (JavascriptExecutor) driver;
 		  vars = new HashMap<String, Object>();
 		  textoBusqueda = "JAiro";
    }
	
   
    

  
    
//    @Before
//    public void setUp() {
//      driver = new ChromeDriver();
//      js = (JavascriptExecutor) driver;
//      vars = new HashMap<String, Object>();
//    }
//    
    @After
    public void tearDown() {
      driver.quit();
    }   
    
	@Test
	public void deletemetest() {
		
	   //	 public static Collection<Object[]> listaTextos() {
			  
	//		  List<Object[]> args = new ArrayList<>();
	     
			//  args.add(new Object[] {"Hola Mundo"});

			  try {
			  
				  String databaseURL = "jdbc:oracle:thin:@LOCALHOST:1521:XE";
				  
				  Connection connection = DriverManager.getConnection(databaseURL,"system","Pa$$w0rd");
				  
					if(connection!=null){
						System.out.println("Conexion establecida");
					}else{
						System.out.println("Error al conectar");
					}
				  
				  
				  
				  String sql = "select DEPTNO,DNAME,CAP from dept";
						  
				  Statement statement = connection.createStatement();
				  
				  ResultSet result = statement.executeQuery(sql);
				  
				
				  
				  while (result.next()) {
					  
					//  Object[] argumento = new Object[] { 
							  
				     System.out.println(result.getString(1));
					 System.out.println(result.getString(2));
					 System.out.println(result.getString(3));
					//concatena = res.getString(2) + ","+ res.getString(3);
					  	//Departamento = "Bogota";
					 Departamento = result.getString(2);
					  };
					  
					//  args.add(argumento);
					  
				 // }
			  }
			  catch (Exception ex) {
				  // Do nothing ... 
			  }
				  
	//	return args;
		//  }
			  
			 

       driver.get("https://www.google.com/");
       driver.manage().window().setSize(new Dimension(1352, 674));
       driver.findElement(By.name("q")).click();
       //driver.findElement(By.name("q")).sendKeys("hola mundo");
      // driver.findElement(By.name("q")).sendKeys(this.textoBusqueda); 
       driver.findElement(By.name("q")).sendKeys(Departamento); 
       driver.findElement(By.name("q")).sendKeys(Keys.ENTER);
       {
         WebElement element = driver.findElement(By.cssSelector(".g:nth-child(1) .LC20lb > span"));
         Actions builder = new Actions(driver);
         builder.moveToElement(element).perform();
       }
     
     
     }

	}
	

	
	
	
	

