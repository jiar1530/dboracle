package com.selenium.test;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Map;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import com.selenium.database.Conectar;
import com.selenium.database.MainConexionOracle;


@RunWith(Parameterized.class)
public class RegistrarHogar_2 {
	
 
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
 // public static String Secuencia;
//  public static String Tipo_Identificacion;
 
    
  //Ubicacion de Elementos
 
  
    By usuario = By.xpath("//*[@id=\"username\"]");
  By clave = By.id("password");
  By BotonIngresar = By.id("sId");
  By CheckForzar = By.xpath("//*[@id=\"forcelogin\"]");
  
  
  String nombre_usuario = "90681";
  String password = "H33std";
  
  //elementos 2do Formulario
  
  By BotonConfiguracionAvanzada = By.id("details-button");
  By LinkContinuar = By.id("proceed-link");

  //elementos 3r Formulario
  
  By CampoBusqueda = By.id("search-query");
  By MiCasaYa = By.xpath("//*[@id=\"id_69\"]/div/a");

  // elementos 4to Formulario
  By RegistrarHogar = By.xpath("//*[@id=\"terceros:tbody_element\"]/tr[2]/td/a");
  
  //Elementos 5 formulario Registro
  By BotonAdicionarIntegrante = By.xpath("//*[@id=\"addMemberButton\"]");
  By DesplegableTipoDocumento = By.xpath("//*[@id=\"tercerosLista:0:identificacion\"]");
  By OpcionCedula = By.xpath("//*[@id=\"tercerosLista:0:identificacion\"]/option[2]");
  By CampoCedula = By.xpath("//*[@id=\"tercerosLista:0:numIdentificacion\"]");
  By DesplegableDepartamento = By.xpath("//*[@id=\"form1:departamento\"]");
  By DesplegableMunicipio = By.xpath("//*[@id=\"form1:municipio\"]");
  By DesplegableRango = By.xpath("//*[@id=\"form1:rango\"]");
  By DesplegableTipoDeVivienda = By.xpath("//*[@id=\"form1:tipoVivienda\"]");
  By BotonValidar = By.xpath("//*[@id=\"validarButton\"]");		 

  //Datos Opcionales
  
  By Fecha_Nacimiento = By.xpath("//*[@id=\"tercerosLista:0:fechaNacimiento\"]");
  By DesplegableGenero = By.xpath("//*[@id=\"tercerosLista:0:genero\"]");
  By DesplegableOrientacion = By.xpath("//*[@id=\"tercerosLista:0:orientacionSexual\"]");
  By DesplegableEstadoCivil = By.xpath("//*[@id=\"tercerosLista:0:estadoCivil\"]");
  By DesplegableCondicionEspecial = By.xpath("//*[@id=\"tercerosLista:0:estadoCivil\"]");
  By DesplegableEtnica = By.xpath("//*[@id=\"tercerosLista:0:pertenenciaEtnica\"]");
  By CheckEliminar = By.xpath("//*[@id=\"tercerosLista:0:_id42\"]/img");
  By Celular = By.xpath("//*[@id=\"form1:celular\"]");
  By Telefono = By.xpath("//*[@id=\"form1:telefonoFijo\"]");
  By CorreoElectronico = By.xpath("//*[@id=\"form1:email\"]");
  By Direccion = By.xpath("//*[@id=\"form1:direccionCorrespondencia\"]");
  By DesplegableContrato = By.xpath("//*[@id=\"form1:tipoContrato\"]");
  
  
   @Parameterized.Parameters   
  
   public static Collection<Object[]> listaTextos() {
		  
	   List<Object[]> args = new ArrayList<>();
	     
	   

	 	 try {
	 		  
	 		Conectar oracle=new Conectar();
	 	 	Connection con;
	 	 	con=oracle.conectar();
	 		  
	 	     //  String sql = "Select * from mcy_hogar ho where ho.id_hogar=3577";
 		    //  String sql = "Select * from mcy_hogar";
 		    // String sql = "select Numero_identificacion,nombre from terceros WHERE ROWNUM <= 10";
	 	 	String sql = "select Numero_identificacion,nombre, lugar_expedicion from terceros WHERE ROWNUM <= 10";
 		     
	 		  Statement statement = con.createStatement();
	 		  
	 		  ResultSet result = statement.executeQuery(sql);
	 		
	 		//Extraer Data
	 		   
	 		  while (result.next()) {
	 			  
	 			  Object[] argumento = new Object[] { 
	 					  
	 					   result.getString(1),
	 					   result.getString(2),
	 					   result.getString(3),
	 					 // result.getString(4),
	 					 
	 			  };
	 		 // }  
	 			  
	 			    args.add(argumento);
	 			//    result.close();
	 			//    statement.close();
	 		//	 System.out.println(repo);
	 		  }
	 		}
	 	catch (Exception ex) {
	 		  // Do nothing ... 
	 	}
	 		  
	 	return args;

	 	}
	 	  
   
   
   public static String Cedula;
   public static String Tipo_Identificacion;
   public static String Municipio;
//   public static String Nombre;
  
   //public RegistrarHogar_1(String Secuencia, String Tipo_Identificacion,String Cedula,String Nombre) {
   public RegistrarHogar_2(String Cedula, String Tipo_Identificacion, String Municipio) {
	   this.Cedula = Cedula;
	   this.Tipo_Identificacion = Tipo_Identificacion;
	   this.Municipio = Municipio;
	//   this.Nombre = Nombre;
   }
  
  @Before
  public void setUp() {
	  
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");
	
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
  @After
  public void tearDown() {
   // driver.quit();
  }
  @Test
  
  public void testRegistro() throws InterruptedException {
	  
	  System.out.println(Cedula);
	  System.out.println(Tipo_Identificacion);
	  System.out.println(Municipio);
  
    driver.get("http://10.1.104.75:9090/sso-auth-server/login");
	
     driver.findElement(usuario).click();
     driver.findElement(usuario).sendKeys(nombre_usuario);
     driver.findElement(clave).click();
     driver.findElement(clave).sendKeys(password);
      driver.findElement(BotonIngresar).click();
     Thread.sleep(2000);
    
    
    
    //Forzar login
//     driver.findElement(CheckForzar).click();
//     Thread.sleep(2000); 
//     driver.findElement(usuario).click();
//     driver.findElement(usuario).sendKeys(nombre_usuario);
//     driver.findElement(clave).click();
//     driver.findElement(clave).sendKeys(password);
//     driver.findElement(BotonIngresar).click();
//    
    
    //2do Formulario/ Conexion no es privada
    driver.findElement(BotonConfiguracionAvanzada).click();
    Thread.sleep(2000);
    driver.findElement(LinkContinuar).click();
    Thread.sleep(2000);

    //3er Formulario /menu escoger proyecto 
    driver.findElement(CampoBusqueda).click();
    driver.findElement(CampoBusqueda).sendKeys("Mi Casa Ya");
    driver.findElement(MiCasaYa).click();
    Thread.sleep(2000);
    
    //4to Formulario /Escoger Opcion Mi Casa Ya.
    driver.findElement(RegistrarHogar).click();
    Thread.sleep(2000);
    
    //5to Formulario //Formulario Registro Hogar
     driver.findElement(BotonAdicionarIntegrante).click();
     Thread.sleep(3000);
     driver.findElement(DesplegableTipoDocumento).click();
     Thread.sleep(2000);
     driver.findElement(OpcionCedula).click();
   //  driver.findElement(CampoCedula).sendKeys("1037479977");
   //  driver.findElement(CampoCedula).sendKeys(Integer.toString(id_hogar));
     driver.findElement(CampoCedula).sendKeys(Cedula);
   //  Thread.sleep(2000);
   // driver.findElement(BotonAdicionarIntegrante).click();
     
     //Datos Opcionales
     
     driver.findElement(Fecha_Nacimiento).sendKeys("11/08/1980");
     driver.findElement(DesplegableGenero).click();
     driver.findElement(DesplegableGenero).sendKeys("Masculino");
     driver.findElement(DesplegableOrientacion).click();
     driver.findElement(DesplegableOrientacion).sendKeys("Heterosexual");
     driver.findElement(DesplegableEstadoCivil).sendKeys("Soltero");
     driver.findElement(DesplegableCondicionEspecial).sendKeys("Cabeza de familia");
     driver.findElement(DesplegableEtnica).sendKeys("Otro /No determinado");
     
     
     //Eliminar Registro
     driver.findElement(CheckEliminar).click(); 
    
     
     js.executeScript("window.scrollBy(0,1000)");
     Thread.sleep(3000);
     driver.findElement(DesplegableDepartamento).click();
     //driver.findElement(DesplegableDepartamento).sendKeys("BOGOTA DISTRITO C.A");
     driver.findElement(DesplegableDepartamento).sendKeys("CESAR");
     driver.findElement(DesplegableDepartamento).click();
     Thread.sleep(3000);
     driver.findElement(DesplegableMunicipio).click();
     //driver.findElement(DesplegableMunicipio).sendKeys("BOGOTA");
     driver.findElement(DesplegableMunicipio).sendKeys(Municipio);
     driver.findElement(DesplegableMunicipio).click();
     Thread.sleep(2000);
     driver.findElement(DesplegableRango).click();
     driver.findElement(DesplegableRango).click();
     driver.findElement(DesplegableRango).sendKeys("3-Hasta 2 smmlv");
     driver.findElement(DesplegableRango).click();
     Thread.sleep(2000);
     driver.findElement(DesplegableTipoDeVivienda).click();
     driver.findElement(DesplegableTipoDeVivienda).sendKeys("VIS");
     Thread.sleep(2000);
     driver.findElement(DesplegableTipoDeVivienda).click();
     Thread.sleep(3000);
     
     //Datos Opcionales
     driver.findElement(Celular).sendKeys("3194371546");
     driver.findElement(Telefono).sendKeys("2500174");
     driver.findElement(CorreoElectronico).sendKeys("retornomedieval@gmail.com");
     driver.findElement(Direccion).sendKeys("Cra 69J No 73a-26");
     driver.findElement(DesplegableContrato).click();
     driver.findElement(DesplegableContrato).sendKeys("Credito");
     
     //Boton Validacion
    // driver.findElement(BotonValidar).click();
    // Thread.sleep(10000);
     
    
     
     
  }
}