package com.selenium.test;

import org.testng.annotations.Test;
import com.selenium.config.BaseConfig;
import com.selenium.database.MainConexionOracle;
import com.selenium.database.DBOracle;
import com.selenium.dataprovider.IntegratedDataProvider;
import com.selenium.entities.Casa;
import com.selenium.page.HomePage;


public class Test01 extends BaseConfig {

	  
  @Test(dataProvider = "buscarCasa", dataProviderClass = IntegratedDataProvider.class )
  public void example01(Casa casa) {
	  
	 //while (true)
	  int i =1;
	  for (i=1;i<=3;i++){
	 
		 System.out.println("entro");
	  HomePage homePage = new HomePage(driver);
	    //cargar data
	    MainConexionOracle mainConexionOracle = new MainConexionOracle();
	    mainConexionOracle.data();
	    // search Proyectos En Oferta method in page (HomePage)
	    System.out.println("SUERTE1");
	    HomePage homepage = homePage.proyectosEnOferta(); 
	   // homePage.validCartItem();
	    System.out.println("SUERTE2");
	 
	  }
	  }
	}
  
  
 
 