
package com.selenium.test;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import com.selenium.database.Conectar;



@RunWith(Parameterized.class)
public class Test06Test {
	
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  

   @Parameterized.Parameters     
  
  public static Collection<Object[]> listaTextos() {
		  
  List<Object[]> args = new ArrayList<>();
    
    Conectar oracle=new Conectar();
	Connection con;
	con=oracle.conectar();

	//1) Funciona Correctamente
	
//		  try {
//			  
//			  String sql = "Select * from mcy_hogar ho where ho.id_hogar=3577";
//			  
//			  Statement statement = con.createStatement();
//			  
//			  ResultSet result = statement.executeQuery(sql);
//			//  result.next();
//			  
//			  String repo ="";
//			  while (result.next()) {
//				  
//				//  Object[] argumento = new Object[] { 
//						  
//			 repo +=result.getString(1)+"\t";
//			 repo +=result.getString(2)+"\t";
//			 repo +=result.getString(3)+"\n\r";
//			 
//				  }
//				  
//			//	  args.add(argumento);
//				 System.out.println(repo);
//			  
//		  }
//		  catch (Exception ex) {
//			  // Do nothing ... 
//		  }
//			  
//	return args;
//	  }
			  
		
// Fin 1
			  
	  try {
	  
	  //String sql = "Select * from mcy_hogar ho where ho.id_hogar=3577";
	  String sql = "Select * from mcy_hogar";
	  
	  
	  Statement statement = con.createStatement();
	  
	  ResultSet result = statement.executeQuery(sql);
	//  result.next();
	  
	//  String repo ="";
	  while (result.next()) {
		  
		  Object[] argumento = new Object[] { 
				  
				  result.getString(1),
				  result.getString(2),
				  result.getString(3),
				  
//	 id_hogar2 +=result.getString(1),
//	 codigo2 +=result.getString(2),
//	 fec_consulta_2 +=result.getString(3),
	 
		  };
		  
		  args.add(argumento);
		  
	  }
}
catch (Exception ex) {
	  // Do nothing ... 
}
	  
return args;
}
	
public static String id_hogar2;
public static String codigo2;
public static String fec_consulta_2;

  
public  Test06Test(String id_hogar2, String codigo2, String fec_consulta_2){
   this.id_hogar2 = id_hogar2;
  this.codigo2 = codigo2;
  this.fec_consulta_2 = fec_consulta_2;
	
}
	
	
	
			  
			
//			  
//			  while (result.next()) {
//				  
//				  Object[] argumento = new Object[] { 
//						  
//			     result.getString(1),
//				 result.getString(2),
//				 result.getString(3),
//			
//				  };
//				  
//				  args.add(argumento);
//				  
//			  }
//		  }
//		  catch (Exception ex) {
//			  // Do nothing ... 
//		  }
//			  
//	return args;
//	  }
		  
//  private final String codigo;
//  private final String Departamento;
//  private final String Capital;  
//		
  	 
  	 
// public  Test06Test(String codigo, String Departamento, String Capital){
// 	     this.codigo = codigo;
//	     this.Departamento = Departamento;
//	     this.Capital = Capital;
// 		
// }
 
  @Before
  public void setUp() {
	System.setProperty("webdriver.chrome.driver", "C:\\Users\\jpataco\\eclipse-workspace\\Proyecto_0\\driver\\chromedriver.exe");  
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void test06() {
	  
	  driver.get("https://www.google.com/");
	    driver.manage().window().setSize(new Dimension(1062, 668));
	    //driver.findElement(By.name("q")).sendKeys("Prueba jairo");
	    driver.findElement(By.name("q")).sendKeys(id_hogar2);
	    driver.findElement(By.id("viewport")).click();
	    driver.findElement(By.cssSelector("center:nth-child(1) > .gNO89b")).click();
	  
  }
}
